#!/bin/bash
#Ejercicio10 - Danny Velasquez
datoUsurio=$1
echo ${#datoUsurio}