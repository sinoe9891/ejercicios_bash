#!/bin/bash
#Ejercicio2 - Danny Velasquez
case $1 in
	1) echo "Uno";;
	2) echo "Dos";;
	3) echo "Tres";;
	4) echo "Cuatro";;
	5) echo "Cinco";;
	*) echo "Dato no válido"
esac