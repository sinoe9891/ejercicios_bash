#!/bin/bash
#Ejercicio9 - Danny Velasquez
uname -a
wslfetch