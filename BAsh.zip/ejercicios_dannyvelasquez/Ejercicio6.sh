#!/bin/bash
#Ejercicio6 - Danny Velasquez
datoUsuario=$1
echo ${datoUsuario:2:3}