#!/bin/bash
#Ejercicio1 - Danny Velasquez
echo Hola mundo
for numero in {1..100..4}
do
	echo $numero
done

