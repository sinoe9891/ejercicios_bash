#!/bin/bash
#Ejercicio5 - Danny Velasquez
./Ejercicio3.sh
echo "Se crearon las carpetas del Ejercicio3.sh"
echo "Espere por favor.."
sleep 10s
./Ejercicio4.sh
ls
echo "Las carpetas fueron eliminadas" 