#!/bin/bash
#Ejercicio3 - Danny Velasquez
datoUsuario='prueba'
for i in {1..30}
do
	rm -d $datoUsuario$i
done